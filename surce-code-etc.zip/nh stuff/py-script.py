#import
import os
import shutil
import subprocess
os.system("pip install colorama")
from colorama import init, Fore, Style
#fukcje



def print_ascii_file_in_yellow(file_path):
 

    if not os.path.exists(file_path):
        print(f"Plik {file_path} nie istnieje.")
        return

    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            print(Fore.YELLOW + content)
    except Exception as e:
        print(f"Wystąpił błąd podczas odczytu pliku: {e}")





def run_installer():
    # Ścieżka do katalogu i instalatora
    directory = "files"
    installer = "nhinstaller.exe"

    # Pełna ścieżka do instalatora
    installer_path = os.path.join(directory, installer)

    # Sprawdź, czy katalog istnieje
    if not os.path.isdir(directory):
        print(f"Katalog {directory} nie istnieje.")
        return

    # Sprawdź, czy plik instalatora istnieje
    if not os.path.isfile(installer_path):
        print(f"Instalator {installer_path} nie istnieje.")
        return

    try:
        # Uruchomienie instalatora
        subprocess.run([installer_path], check=True)
        print("Instalacja zakończona pomyślnie.")
    except subprocess.CalledProcessError as e:
        print(f"Błąd podczas uruchamiania instalatora: {e}")



def copy_file_to_desktop():
    # Pobierz ścieżkę do katalogu domowego użytkownika
    user_profile = os.environ['USERPROFILE']
    # Utwórz pełną ścieżkę do pulpitu
    desktop_path = os.path.join(user_profile, 'Desktop')
    # Utwórz pełną ścieżkę do pliku źródłowego w folderze 'files'
    source_directory = os.path.join(os.path.dirname(__file__), 'files')
    source_path = os.path.join(source_directory, 'adress.txt')
    # Utwórz pełną ścieżkę docelową pliku na pulpicie
    destination = os.path.join(desktop_path, 'adress.txt')

    # Sprawdź, czy katalog 'files' istnieje
    if not os.path.exists(source_directory):
        print(f"Katalog {source_directory} nie istnieje.")
        return
    
    # Sprawdź, czy plik 'adress.txt' istnieje w katalogu 'files'
    if not os.path.isfile(source_path):
        print(f"Plik {source_path} nie istnieje.")
        return
    
    try:
        # Skopiuj plik do pulpitu
        shutil.copy(source_path, destination)
        print(f"Plik {source_path} został skopiowany na pulpit użytkownika: {destination}")
    except Exception as e:
        print(f"Wystąpił błąd podczas kopiowania pliku: {e}")

# Wywołanie funkcji
copy_file_to_desktop()




#działanie







# Wywołanie funkcji
print_ascii_file_in_yellow('files\ASCII.txt')

print(Fore.GREEN +"opening the installer")

# Wywołanie funkcji
run_installer()

print("generating btc wallet adress.txt")




